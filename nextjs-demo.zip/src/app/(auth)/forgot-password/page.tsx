export default function ForgotPassword (){
    return <h1>Forgot Password</h1>
}