export default function FirstPost (){
    return <h1>First Post</h1>
}