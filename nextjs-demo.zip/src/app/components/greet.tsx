export const Greet = () =>{
    console.log("greet component");
    return <h1>Greet Component</h1>
};